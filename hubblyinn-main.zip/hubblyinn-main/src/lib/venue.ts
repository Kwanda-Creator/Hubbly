export const VENUE = {
  name: "EMA Hubbly Inn",
  area: "Maboneng, Johannesburg",
  address: "20 Kruger Street, Maboneng, Johannesburg",
  email: "support@hubblyinn.com",
  phonePrimary: "081 888 5130",
  phoneAlt: "075 019 1020",
  phonePrimaryTel: "+27818885130",
  phoneAltTel: "+27750191020",
  whatsappPrimary: "27818885130",
  whatsappAlt: "27750191020",
  hoursDays: "Thursday – Sunday",
  hoursTime: "1 PM – Till Late",
  grandOpening: "2026-09-05T13:00:00+02:00",
  mapsQuery: "20+Kruger+Street,+Maboneng,+Johannesburg",
} as const;

export const DIRECTIONS_URL = `https://www.google.com/maps/dir/?api=1&destination=${VENUE.mapsQuery}`;
export const MAP_EMBED_URL = `https://www.google.com/maps?q=${VENUE.mapsQuery}&z=16&output=embed`;

export const waLink = (number: string, message: string) =>
  `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
