import { useEffect, useRef, useState, type ReactNode } from "react";
import { cn } from "@/lib/utils";

/** Drifting smoke plumes + rising gold particles. Purely decorative. */
export function Atmosphere({ dense = false }: { dense?: boolean }) {
  const particles = Array.from({ length: dense ? 18 : 10 }, (_, i) => ({
    left: `${(i * 97) % 100}%`,
    delay: `${(i * 1.7) % 12}s`,
    duration: `${11 + ((i * 3) % 9)}s`,
    size: i % 3 === 0 ? 3 : 2,
  }));

  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 overflow-hidden">
      <div className="absolute -left-1/4 top-0 h-[70vh] w-[70vw] animate-smoke rounded-full bg-[radial-gradient(circle,color-mix(in_oklab,var(--gold)_16%,transparent),transparent_65%)] blur-3xl" />
      <div
        className="absolute -right-1/4 bottom-0 h-[65vh] w-[65vw] animate-smoke rounded-full bg-[radial-gradient(circle,color-mix(in_oklab,var(--bronze)_22%,transparent),transparent_68%)] blur-3xl"
        style={{ animationDelay: "-9s" }}
      />
      <div
        className="absolute left-1/3 top-1/4 h-[45vh] w-[55vw] animate-smoke rounded-full bg-[radial-gradient(circle,color-mix(in_oklab,var(--foreground)_7%,transparent),transparent_70%)] blur-3xl"
        style={{ animationDelay: "-16s" }}
      />
      {particles.map((p, i) => (
        <span
          key={i}
          className="animate-particle absolute bottom-0 rounded-full bg-gold"
          style={{
            left: p.left,
            width: p.size,
            height: p.size,
            animationDelay: p.delay,
            animationDuration: p.duration,
            boxShadow: "0 0 8px color-mix(in oklab, var(--gold) 70%, transparent)",
          }}
        />
      ))}
    </div>
  );
}

/** Scroll reveal wrapper. */
export function Reveal({
  children,
  delay = 0,
  className,
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry?.isIntersecting) {
          setShown(true);
          io.disconnect();
        }
      },
      { threshold: 0.15, rootMargin: "0px 0px -8% 0px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className={cn("reveal", shown && "reveal-in", className)}
      style={{ transitionDelay: `${delay}ms` }}
    >
      {children}
    </div>
  );
}

export function SectionHeading({
  label,
  title,
  className,
}: {
  label: string;
  title: string;
  className?: string;
}) {
  return (
    <div className={cn("text-center", className)}>
      <p className="section-label">{label}</p>
      <h2 className="mt-4 text-3xl font-light leading-tight sm:text-4xl md:text-5xl">
        <span className="text-gold-gradient">{title}</span>
      </h2>
      <div className="gold-rule mx-auto mt-6 w-32" />
    </div>
  );
}
