import { MapPin, CalendarCheck, Phone, Sparkles } from "lucide-react";
import heroImg from "@/assets/hero-hubbly.jpg";
import logo from "@/assets/ema-logo.png.asset.json";
import { Atmosphere } from "./atmosphere";
import { VENUE, DIRECTIONS_URL } from "@/lib/venue";

export function Hero() {
  return (
    <section id="top" className="relative isolate flex min-h-[100svh] items-center overflow-hidden">
      <img
        src={heroImg}
        alt="Ornate gold hubbly with smoke in a candlelit lounge"
        width={1600}
        height={1104}
        className="absolute inset-0 h-full w-full object-cover opacity-45"
      />
      <div className="absolute inset-0 night-gradient" />
      <div className="absolute inset-0 bg-[linear-gradient(to_top,var(--background)_2%,transparent_45%)]" />
      <Atmosphere dense />

      <div className="relative mx-auto w-full max-w-4xl px-5 pb-28 pt-28 text-center sm:pb-24">
        <div className="animate-fade-in flex justify-center">
          <img
            src={logo.url}
            alt="EMA Hubbly Inn"
            width={180}
            height={180}
            className="h-28 w-28 rounded-full ring-1 ring-gold/40 sm:h-36 sm:w-36"
          />
        </div>

        <div className="animate-fade-in mt-7 inline-flex items-center gap-2 rounded-full border border-gold/40 bg-charcoal/60 px-4 py-1.5 backdrop-blur">
          <Sparkles className="h-3.5 w-3.5 text-gold" />
          <span className="text-[0.62rem] font-semibold uppercase tracking-[0.28em] text-gold-light sm:text-[0.7rem]">
            Grand Opening — 5 September 2026
          </span>
        </div>

        <h1 className="animate-fade-in mt-6 text-[2.6rem] font-light leading-[0.95] sm:text-6xl md:text-7xl">
          <span className="shimmer-text">EMA HUBBLY INN</span>
        </h1>

        <p className="animate-fade-in mt-5 text-[0.68rem] font-medium uppercase tracking-[0.3em] text-foreground/80 sm:text-sm sm:tracking-[0.42em]">
          Maboneng's Premier Nightlife Destination
        </p>

        <div className="gold-rule mx-auto mt-7 w-40" />

        <p className="animate-fade-in mx-auto mt-7 max-w-xl text-sm leading-relaxed text-muted-foreground sm:text-base">
          Good vibes. Great music. Premium hubblies. Ice cold drinks.
        </p>

        <div className="animate-fade-in mt-9 flex flex-col items-stretch justify-center gap-3 sm:flex-row sm:items-center">
          <a
            href="#booking"
            className="glow-gold inline-flex items-center justify-center gap-2 rounded-full bg-gold-gradient px-7 py-3.5 text-xs font-semibold uppercase tracking-[0.2em] text-primary-foreground transition-transform hover:scale-[1.04]"
          >
            <CalendarCheck className="h-4 w-4" /> Book a Table
          </a>
          <a
            href="#contact"
            className="inline-flex items-center justify-center gap-2 rounded-full border border-gold/50 px-7 py-3.5 text-xs font-semibold uppercase tracking-[0.2em] text-gold transition-colors hover:bg-gold/10"
          >
            <Phone className="h-4 w-4" /> Contact Us
          </a>
          <a
            href={DIRECTIONS_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 rounded-full border border-border px-7 py-3.5 text-xs font-semibold uppercase tracking-[0.2em] text-foreground/80 transition-colors hover:border-gold/50 hover:text-gold"
          >
            <MapPin className="h-4 w-4" /> Get Directions
          </a>
        </div>

        <p className="mt-10 text-[0.6rem] uppercase tracking-[0.3em] text-muted-foreground">
          {VENUE.hoursDays} · {VENUE.hoursTime} · 18+ · Coolerbox Allowed
        </p>
      </div>
    </section>
  );
}
