import { useState } from "react";
import { z } from "zod";
import { CalendarCheck, Check, MessageCircle } from "lucide-react";
import { Reveal, SectionHeading } from "./atmosphere";
import { VENUE, waLink } from "@/lib/venue";

const schema = z.object({
  name: z.string().trim().min(2, "Please enter your full name").max(80),
  phone: z
    .string()
    .trim()
    .min(9, "Please enter a valid phone number")
    .max(20)
    .regex(/^[0-9+()\s-]+$/, "Phone number can only contain digits and + ( ) -"),
  email: z.string().trim().email("Please enter a valid email").max(160),
  date: z.string().min(1, "Choose a date"),
  time: z.string().min(1, "Choose a time"),
  guests: z.coerce.number().int().min(1, "At least 1 guest").max(50, "Call us for groups over 50"),
  request: z.string().trim().max(500, "Please keep it under 500 characters").optional(),
});

type Errors = Partial<Record<keyof z.infer<typeof schema>, string>>;

const FIELD =
  "w-full rounded-md border border-input bg-background/60 px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground/70 outline-none transition-colors focus:border-gold focus:ring-1 focus:ring-ring";
const LABEL = "mb-2 block text-[0.6rem] uppercase tracking-[0.24em] text-muted-foreground";

export function Booking() {
  const [errors, setErrors] = useState<Errors>({});
  const [done, setDone] = useState<z.infer<typeof schema> | null>(null);

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.currentTarget));
    const parsed = schema.safeParse(data);
    if (!parsed.success) {
      const next: Errors = {};
      for (const issue of parsed.error.issues) {
        const key = issue.path[0] as keyof Errors;
        if (!next[key]) next[key] = issue.message;
      }
      setErrors(next);
      return;
    }
    setErrors({});
    setDone(parsed.data);
  };

  if (done) {
    const summary = `Booking request — ${done.name}\nDate: ${done.date} at ${done.time}\nGuests: ${done.guests}\nPhone: ${done.phone}\nEmail: ${done.email}${
      done.request ? `\nRequest: ${done.request}` : ""
    }`;

    return (
      <section id="booking" className="relative py-24 sm:py-32">
        <div className="mx-auto max-w-2xl px-5">
          <Reveal>
            <div className="glass-card rounded-lg p-10 text-center">
              <span className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-gold/50 text-gold">
                <Check className="h-7 w-7" />
              </span>
              <h2 className="mt-6 text-3xl font-light sm:text-4xl">
                <span className="text-gold-gradient">Table Requested</span>
              </h2>
              <div className="gold-rule mx-auto mt-5 w-28" />
              <p className="mt-6 text-sm leading-relaxed text-muted-foreground">
                Thank you, {done.name}. We've got your request for{" "}
                <span className="text-gold-light">
                  {done.guests} {done.guests === 1 ? "guest" : "guests"}
                </span>{" "}
                on <span className="text-gold-light">{done.date}</span> at{" "}
                <span className="text-gold-light">{done.time}</span>. Send it through on WhatsApp to
                lock it in instantly, or our team will confirm on {done.phone}.
              </p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:justify-center">
                <a
                  href={waLink(VENUE.whatsappPrimary, summary)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="glow-gold inline-flex items-center justify-center gap-2 rounded-full bg-gold-gradient px-7 py-3.5 text-xs font-semibold uppercase tracking-[0.2em] text-primary-foreground transition-transform hover:scale-105"
                >
                  <MessageCircle className="h-4 w-4" /> Confirm on WhatsApp
                </a>
                <button
                  type="button"
                  onClick={() => setDone(null)}
                  className="inline-flex items-center justify-center rounded-full border border-gold/50 px-7 py-3.5 text-xs font-semibold uppercase tracking-[0.2em] text-gold transition-colors hover:bg-gold/10"
                >
                  Make Another Booking
                </button>
              </div>
            </div>
          </Reveal>
        </div>
      </section>
    );
  }

  return (
    <section id="booking" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-3xl px-5">
        <Reveal>
          <SectionHeading label="Reservations" title="Book a Table" />
          <p className="mx-auto mt-6 max-w-lg text-center text-sm text-muted-foreground">
            Tell us when you're coming through and how many of you there'll be. We'll hold the
            couch.
          </p>
        </Reveal>

        <Reveal delay={120}>
          <form onSubmit={onSubmit} noValidate className="glass-card mt-12 rounded-lg p-6 sm:p-9">
            <div className="grid gap-5 sm:grid-cols-2">
              <div className="sm:col-span-2">
                <label className={LABEL} htmlFor="name">
                  Full Name
                </label>
                <input id="name" name="name" className={FIELD} placeholder="Your name" maxLength={80} />
                {errors.name && <p className="mt-2 text-xs text-destructive">{errors.name}</p>}
              </div>
              <div>
                <label className={LABEL} htmlFor="phone">
                  Phone Number
                </label>
                <input
                  id="phone"
                  name="phone"
                  type="tel"
                  className={FIELD}
                  placeholder="081 000 0000"
                  maxLength={20}
                />
                {errors.phone && <p className="mt-2 text-xs text-destructive">{errors.phone}</p>}
              </div>
              <div>
                <label className={LABEL} htmlFor="email">
                  Email
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  className={FIELD}
                  placeholder="you@email.com"
                  maxLength={160}
                />
                {errors.email && <p className="mt-2 text-xs text-destructive">{errors.email}</p>}
              </div>
              <div>
                <label className={LABEL} htmlFor="date">
                  Date
                </label>
                <input id="date" name="date" type="date" className={FIELD} />
                {errors.date && <p className="mt-2 text-xs text-destructive">{errors.date}</p>}
              </div>
              <div>
                <label className={LABEL} htmlFor="time">
                  Time
                </label>
                <input id="time" name="time" type="time" className={FIELD} defaultValue="19:00" />
                {errors.time && <p className="mt-2 text-xs text-destructive">{errors.time}</p>}
              </div>
              <div className="sm:col-span-2">
                <label className={LABEL} htmlFor="guests">
                  Number of Guests
                </label>
                <input
                  id="guests"
                  name="guests"
                  type="number"
                  min={1}
                  max={50}
                  defaultValue={2}
                  className={FIELD}
                />
                {errors.guests && <p className="mt-2 text-xs text-destructive">{errors.guests}</p>}
              </div>
              <div className="sm:col-span-2">
                <label className={LABEL} htmlFor="request">
                  Special Request
                </label>
                <textarea
                  id="request"
                  name="request"
                  rows={4}
                  maxLength={500}
                  className={FIELD}
                  placeholder="Birthday, flavour preference, seating…"
                />
                {errors.request && <p className="mt-2 text-xs text-destructive">{errors.request}</p>}
              </div>
            </div>

            <button
              type="submit"
              className="glow-gold mt-8 inline-flex w-full items-center justify-center gap-2 rounded-full bg-gold-gradient px-8 py-4 text-xs font-semibold uppercase tracking-[0.22em] text-primary-foreground transition-transform hover:scale-[1.02]"
            >
              <CalendarCheck className="h-4 w-4" /> Book Now
            </button>
          </form>
        </Reveal>
      </div>
    </section>
  );
}
