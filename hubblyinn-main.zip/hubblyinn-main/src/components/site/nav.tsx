import { useEffect, useState } from "react";
import { Menu, X, Phone, MessageCircle, CalendarCheck } from "lucide-react";
import logo from "@/assets/ema-logo.png.asset.json";
import { VENUE, waLink } from "@/lib/venue";
import { cn } from "@/lib/utils";

const LINKS = [
  { href: "#about", label: "About" },
  { href: "#experience", label: "Experience" },
  { href: "#gallery", label: "Gallery" },
  { href: "#opening", label: "Grand Opening" },
  { href: "#location", label: "Location" },
  { href: "#booking", label: "Book" },
];

export function SiteNav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <header
        className={cn(
          "fixed inset-x-0 top-0 z-50 transition-all duration-500",
          scrolled ? "glass-card border-x-0 border-t-0 py-2" : "border-transparent py-4",
        )}
      >
        <nav className="mx-auto flex max-w-7xl items-center justify-between px-4 sm:px-6">
          <a href="#top" className="flex items-center gap-3">
            <img
              src={logo.url}
              alt="EMA Hubbly Inn logo"
              width={48}
              height={48}
              className="h-11 w-11 rounded-full ring-1 ring-gold/40"
            />
            <span className="hidden text-sm tracking-[0.32em] text-gold sm:block">
              EMA HUBBLY INN
            </span>
          </a>

          <div className="hidden items-center gap-8 lg:flex">
            {LINKS.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="text-xs uppercase tracking-[0.22em] text-muted-foreground transition-colors hover:text-gold"
              >
                {l.label}
              </a>
            ))}
            <a
              href="#booking"
              className="rounded-full bg-gold-gradient px-5 py-2 text-xs font-semibold uppercase tracking-[0.18em] text-primary-foreground transition-transform hover:scale-105"
            >
              Book a Table
            </a>
          </div>

          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-label={open ? "Close menu" : "Open menu"}
            aria-expanded={open}
            className="rounded-full border border-border p-2.5 text-gold lg:hidden"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </nav>

        {open && (
          <div className="glass-card mx-4 mt-3 rounded-lg p-5 lg:hidden">
            <div className="grid gap-1">
              {LINKS.map((l) => (
                <a
                  key={l.href}
                  href={l.href}
                  onClick={() => setOpen(false)}
                  className="border-b border-border/40 py-3 text-sm uppercase tracking-[0.22em] text-foreground/90 last:border-0"
                >
                  {l.label}
                </a>
              ))}
            </div>
          </div>
        )}
      </header>

      {/* Mobile action bar */}
      <div className="glass-card fixed inset-x-0 bottom-0 z-50 grid grid-cols-3 border-x-0 border-b-0 lg:hidden">
        <a
          href="#booking"
          className="flex flex-col items-center gap-1 py-3 text-[0.62rem] font-semibold uppercase tracking-[0.16em] text-primary-foreground bg-gold-gradient"
        >
          <CalendarCheck className="h-4 w-4" />
          Book Now
        </a>
        <a
          href={waLink(VENUE.whatsappPrimary, `Hi ${VENUE.name}, I'd like to enquire about a table.`)}
          target="_blank"
          rel="noopener noreferrer"
          className="flex flex-col items-center gap-1 py-3 text-[0.62rem] font-semibold uppercase tracking-[0.16em] text-gold"
        >
          <MessageCircle className="h-4 w-4" />
          WhatsApp
        </a>
        <a
          href={`tel:${VENUE.phonePrimaryTel}`}
          className="flex flex-col items-center gap-1 py-3 text-[0.62rem] font-semibold uppercase tracking-[0.16em] text-gold"
        >
          <Phone className="h-4 w-4" />
          Call
        </a>
      </div>
    </>
  );
}
