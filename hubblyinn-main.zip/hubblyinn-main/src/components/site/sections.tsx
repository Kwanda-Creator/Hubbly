import { useEffect, useState } from "react";
import {
  Flame,
  Music4,
  Mic2,
  Wine,
  Sofa,
  Snowflake,
  Clock,
  MapPin,
  Phone,
  Mail,
  MessageCircle,
  Instagram,
  Facebook,
  Music2,
  X,
} from "lucide-react";
import { Atmosphere, Reveal, SectionHeading } from "./atmosphere";
import { VENUE, DIRECTIONS_URL, MAP_EMBED_URL, waLink } from "@/lib/venue";
import mabonengImg from "@/assets/maboneng-night.jpg";
import loungeImg from "@/assets/gallery-lounge.jpg";
import drinksImg from "@/assets/gallery-drinks.jpg";
import musicImg from "@/assets/gallery-music.jpg";
import hubblyDetailImg from "@/assets/gallery-hubbly-detail.jpg";
import hubbliesImg from "@/assets/gallery-hubblies.jpg";
import heroImg from "@/assets/hero-hubbly.jpg";
import logo from "@/assets/ema-logo.png.asset.json";

export function About() {
  return (
    <section id="about" className="relative overflow-hidden py-24 sm:py-32">
      <Atmosphere />
      <div className="relative mx-auto max-w-6xl px-5">
        <Reveal>
          <SectionHeading label="About the venue" title="Welcome to EMA Hubbly Inn" />
        </Reveal>

        <div className="mt-14 grid items-center gap-12 lg:grid-cols-2">
          <Reveal delay={80}>
            <div className="space-y-5 text-sm leading-relaxed text-muted-foreground sm:text-base">
              <p>
                Tucked into the heart of Maboneng, EMA Hubbly Inn is a premium hubbly lounge built
                for late nights and long conversations — smooth flavour clouds, deep basslines and
                ice cold drinks under warm gold light.
              </p>
              <p>
                Come through with your people, claim a couch, load a premium hubbly and let the
                night stretch. Thursday to Sunday we run from 1 PM till late, coolerboxes welcome,
                strictly 18+.
              </p>
              <p className="text-lg text-gold sm:text-xl" style={{ fontFamily: "var(--font-display)" }}>
                “Good Vibes. Great People. Unforgettable Nights.”
              </p>
            </div>
          </Reveal>

          <Reveal delay={160}>
            <div className="relative overflow-hidden rounded-lg glow-gold">
              <img
                src={mabonengImg}
                alt="Maboneng streets at night, Johannesburg"
                loading="lazy"
                width={1408}
                height={1008}
                className="h-[22rem] w-full object-cover opacity-80 sm:h-[26rem]"
              />
              <div className="absolute inset-0 bg-[linear-gradient(to_top,var(--background),transparent_65%)]" />
              <div className="absolute inset-x-0 bottom-0 p-6 text-center">
                <p className="text-2xl font-light tracking-[0.16em] sm:text-4xl">
                  <span className="text-gold-gradient">THIS IS MABONENG</span>
                </p>
                <div className="gold-rule mx-auto mt-3 w-24" />
                <p className="mt-3 text-[0.6rem] uppercase tracking-[0.3em] text-muted-foreground">
                  Johannesburg · City of Lights
                </p>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

const FEATURES = [
  {
    icon: Flame,
    title: "Premium Hubbly Experience",
    text: "Immaculately packed bowls, premium flavours and smooth clouds every single session.",
  },
  {
    icon: Music4,
    title: "Great Music",
    text: "Amapiano, Afro house and hip hop curated to carry the room from sunset to late.",
  },
  {
    icon: Mic2,
    title: "Live Entertainment",
    text: "Guest DJs, live sets and special nights that turn a normal weekend into a moment.",
  },
  {
    icon: Wine,
    title: "Ice Cold Drinks",
    text: "Chilled beers, spirits and mixers served properly cold, poured all night long.",
  },
  {
    icon: Sofa,
    title: "Chilled Nightlife Atmosphere",
    text: "Low gold lighting, lounge seating and space to actually hear your people talk.",
  },
  {
    icon: Snowflake,
    title: "Coolerbox Allowed",
    text: "Bring your own coolerbox and settle in — the vibe is yours to build.",
  },
];

export function Experience() {
  return (
    <section id="experience" className="relative overflow-hidden bg-charcoal/40 py-24 sm:py-32">
      <div className="relative mx-auto max-w-6xl px-5">
        <Reveal>
          <SectionHeading label="The experience" title="Built For The Night" />
        </Reveal>
        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f, i) => (
            <Reveal key={f.title} delay={i * 70}>
              <article className="glass-card group h-full rounded-lg p-7 transition-all duration-500 hover:-translate-y-1.5 hover:border-gold/60 hover:shadow-[0_0_50px_-18px_color-mix(in_oklab,var(--gold)_60%,transparent)]">
                <span className="inline-flex h-12 w-12 items-center justify-center rounded-full border border-gold/40 text-gold transition-colors group-hover:bg-gold/10">
                  <f.icon className="h-5 w-5" />
                </span>
                <h3 className="mt-5 text-xl font-normal text-gold-light">{f.title}</h3>
                <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{f.text}</p>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

const GALLERY = [
  { src: hubbliesImg, alt: "Two premium hubblies set up on a lounge table" },
  { src: loungeImg, alt: "Dark luxury lounge interior with gold lighting" },
  { src: mabonengImg, alt: "Maboneng architecture at night" },
  { src: musicImg, alt: "DJ under golden light beams" },
  { src: drinksImg, alt: "Ice cold drink on a dark bar top" },
  { src: hubblyDetailImg, alt: "Close up of a gold hubbly bowl with glowing coals" },
  { src: heroImg, alt: "Hubbly and smoke in warm venue lighting" },
];

export function Gallery() {
  const [active, setActive] = useState<number | null>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setActive(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <section id="gallery" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-6xl px-5">
        <Reveal>
          <SectionHeading label="Gallery" title="Inside The Vibe" />
        </Reveal>

        <div className="mt-14 grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4">
          {GALLERY.map((img, i) => (
            <Reveal key={img.alt} delay={i * 50} className={i === 0 ? "col-span-2 row-span-2" : ""}>
              <button
                type="button"
                onClick={() => setActive(i)}
                className="group relative block h-full w-full overflow-hidden rounded-lg border border-border/60 transition-colors hover:border-gold/60"
              >
                <img
                  src={img.src}
                  alt={img.alt}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                  style={{ aspectRatio: i === 0 ? "1 / 1" : "1 / 1" }}
                />
                <span className="absolute inset-0 bg-[linear-gradient(to_top,var(--background),transparent_60%)] opacity-70 transition-opacity group-hover:opacity-30" />
              </button>
            </Reveal>
          ))}
        </div>
      </div>

      {active !== null && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Gallery image"
          onClick={() => setActive(null)}
          className="fixed inset-0 z-[60] flex items-center justify-center bg-background/95 p-4 backdrop-blur-md animate-fade-in"
        >
          <button
            type="button"
            aria-label="Close image"
            className="absolute right-5 top-5 rounded-full border border-gold/40 p-2.5 text-gold"
            onClick={() => setActive(null)}
          >
            <X className="h-5 w-5" />
          </button>
          <figure className="max-h-full w-full max-w-3xl text-center" onClick={(e) => e.stopPropagation()}>
            <img
              src={GALLERY[active]!.src}
              alt={GALLERY[active]!.alt}
              className="mx-auto max-h-[75vh] w-auto rounded-lg glow-gold"
            />
            <figcaption className="mt-4 text-xs uppercase tracking-[0.24em] text-muted-foreground">
              {GALLERY[active]!.alt}
            </figcaption>
          </figure>
        </div>
      )}
    </section>
  );
}

function useCountdown(target: string) {
  const [left, setLeft] = useState(0);
  useEffect(() => {
    const tick = () => setLeft(Math.max(0, new Date(target).getTime() - Date.now()));
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [target]);

  const s = Math.floor(left / 1000);
  return {
    days: Math.floor(s / 86400),
    hours: Math.floor((s % 86400) / 3600),
    minutes: Math.floor((s % 3600) / 60),
    seconds: s % 60,
    done: left === 0,
  };
}

export function GrandOpening() {
  const { days, hours, minutes, seconds, done } = useCountdown(VENUE.grandOpening);
  const units = [
    { label: "Days", value: days },
    { label: "Hours", value: hours },
    { label: "Minutes", value: minutes },
    { label: "Seconds", value: seconds },
  ];

  return (
    <section id="opening" className="relative isolate overflow-hidden py-24 sm:py-32">
      <img
        src={loungeImg}
        alt=""
        aria-hidden
        loading="lazy"
        className="absolute inset-0 h-full w-full object-cover opacity-30"
      />
      <div className="absolute inset-0 night-gradient" />
      <Atmosphere dense />
      <div className="relative mx-auto max-w-4xl px-5 text-center">
        <Reveal>
          <p className="section-label">Save the date</p>
          <h2 className="mt-4 text-4xl font-light leading-none sm:text-6xl">
            <span className="shimmer-text">GRAND OPENING</span>
          </h2>
          <p className="mt-5 text-lg tracking-[0.28em] text-gold-light sm:text-2xl">
            5 SEPTEMBER 2026
          </p>
          <div className="gold-rule mx-auto mt-6 w-40" />
        </Reveal>

        <Reveal delay={120}>
          <div className="mt-12 grid grid-cols-4 gap-2 sm:gap-4">
            {units.map((u) => (
              <div key={u.label} className="glass-card rounded-lg px-2 py-5 sm:py-7">
                <p className="text-3xl font-light tabular-nums sm:text-5xl">
                  <span className="text-gold-gradient">{String(u.value).padStart(2, "0")}</span>
                </p>
                <p className="mt-2 text-[0.55rem] uppercase tracking-[0.24em] text-muted-foreground sm:text-[0.65rem]">
                  {u.label}
                </p>
              </div>
            ))}
          </div>
        </Reveal>

        <Reveal delay={200}>
          <p className="mt-9 text-sm text-muted-foreground">
            {done
              ? "The doors are open — pull through to 20 Kruger Street."
              : "Doors open 1 PM. Tables are limited — reserve yours early."}
          </p>
          <a
            href="#booking"
            className="glow-gold mt-7 inline-flex items-center justify-center rounded-full bg-gold-gradient px-8 py-3.5 text-xs font-semibold uppercase tracking-[0.2em] text-primary-foreground transition-transform hover:scale-105"
          >
            Reserve for Opening Night
          </a>
        </Reveal>
      </div>
    </section>
  );
}

export function Hours() {
  return (
    <section id="hours" className="relative bg-charcoal/40 py-20 sm:py-24">
      <div className="mx-auto max-w-3xl px-5">
        <Reveal>
          <div className="glass-card relative overflow-hidden rounded-lg p-10 text-center">
            <span className="relative mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-gold/50 text-gold">
              <span className="absolute inset-0 animate-pulse-ring rounded-full" />
              <Clock className="h-7 w-7" />
            </span>
            <p className="section-label mt-6">Opening hours</p>
            <h2 className="mt-4 text-3xl font-light sm:text-4xl">
              <span className="text-gold-gradient">{VENUE.hoursDays.toUpperCase()}</span>
            </h2>
            <div className="gold-rule mx-auto mt-5 w-28" />
            <p className="mt-5 text-lg tracking-[0.24em] text-gold-light sm:text-2xl">
              1 PM – TILL LATE
            </p>
            <p className="mt-6 text-[0.6rem] uppercase tracking-[0.28em] text-muted-foreground">
              Coolerbox allowed · Strictly 18+
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export function Location() {
  return (
    <section id="location" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-6xl px-5">
        <Reveal>
          <SectionHeading label="Find us" title="Location" />
        </Reveal>
        <div className="mt-14 grid gap-8 lg:grid-cols-[0.9fr_1.1fr]">
          <Reveal>
            <div className="glass-card h-full rounded-lg p-8">
              <MapPin className="h-6 w-6 text-gold" />
              <h3 className="mt-5 text-2xl font-normal tracking-[0.14em] text-gold-light">
                EMA HUBBLY INN
              </h3>
              <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
                20 Kruger Street
                <br />
                Maboneng, Johannesburg
              </p>
              <p className="mt-6 text-[0.6rem] uppercase tracking-[0.26em] text-muted-foreground">
                {VENUE.hoursDays} · {VENUE.hoursTime}
              </p>
              <a
                href={DIRECTIONS_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="glow-gold mt-8 inline-flex items-center gap-2 rounded-full bg-gold-gradient px-7 py-3 text-xs font-semibold uppercase tracking-[0.2em] text-primary-foreground transition-transform hover:scale-105"
              >
                <MapPin className="h-4 w-4" /> Get Directions
              </a>
            </div>
          </Reveal>
          <Reveal delay={120}>
            <div className="overflow-hidden rounded-lg border border-border">
              <iframe
                title="EMA Hubbly Inn location map"
                src={MAP_EMBED_URL}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                className="h-[22rem] w-full sm:h-[26rem]"
              />
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

export function Contact() {
  const waMessage = `Hi ${VENUE.name}, I'd like to enquire about a table.`;
  return (
    <section id="contact" className="relative overflow-hidden bg-charcoal/40 py-24 sm:py-32">
      <Atmosphere />
      <div className="relative mx-auto max-w-5xl px-5">
        <Reveal>
          <SectionHeading label="Get in touch" title="Contact Us" />
        </Reveal>

        <div className="mt-14 grid gap-5 sm:grid-cols-3">
          {[
            { icon: Phone, label: "Phone", value: VENUE.phonePrimary, href: `tel:${VENUE.phonePrimaryTel}` },
            { icon: Phone, label: "Alternative", value: VENUE.phoneAlt, href: `tel:${VENUE.phoneAltTel}` },
            { icon: Mail, label: "Email", value: VENUE.email, href: `mailto:${VENUE.email}` },
          ].map((c, i) => (
            <Reveal key={c.value} delay={i * 70}>
              <a
                href={c.href}
                className="glass-card block rounded-lg p-7 text-center transition-all hover:-translate-y-1 hover:border-gold/60"
              >
                <c.icon className="mx-auto h-5 w-5 text-gold" />
                <p className="mt-4 text-[0.6rem] uppercase tracking-[0.28em] text-muted-foreground">
                  {c.label}
                </p>
                <p className="mt-2 break-words text-sm text-gold-light">{c.value}</p>
              </a>
            </Reveal>
          ))}
        </div>

        <Reveal delay={200}>
          <div className="mt-10 flex flex-col gap-3 sm:flex-row sm:justify-center">
            <a
              href={`tel:${VENUE.phonePrimaryTel}`}
              className="inline-flex items-center justify-center gap-2 rounded-full border border-gold/50 px-7 py-3.5 text-xs font-semibold uppercase tracking-[0.2em] text-gold transition-colors hover:bg-gold/10"
            >
              <Phone className="h-4 w-4" /> Call Us
            </a>
            <a
              href={`mailto:${VENUE.email}`}
              className="inline-flex items-center justify-center gap-2 rounded-full border border-border px-7 py-3.5 text-xs font-semibold uppercase tracking-[0.2em] text-foreground/80 transition-colors hover:border-gold/50 hover:text-gold"
            >
              <Mail className="h-4 w-4" /> Email Us
            </a>
            <a
              href={waLink(VENUE.whatsappPrimary, waMessage)}
              target="_blank"
              rel="noopener noreferrer"
              className="glow-gold inline-flex items-center justify-center gap-2 rounded-full bg-gold-gradient px-7 py-3.5 text-xs font-semibold uppercase tracking-[0.2em] text-primary-foreground transition-transform hover:scale-105"
            >
              <MessageCircle className="h-4 w-4" /> WhatsApp Us
            </a>
          </div>
          <p className="mt-4 text-center text-[0.6rem] uppercase tracking-[0.24em] text-muted-foreground">
            Second line on WhatsApp:{" "}
            <a
              className="text-gold hover:underline"
              href={waLink(VENUE.whatsappAlt, waMessage)}
              target="_blank"
              rel="noopener noreferrer"
            >
              {VENUE.phoneAlt}
            </a>
          </p>
        </Reveal>
      </div>
    </section>
  );
}

const SOCIALS = [
  { icon: Instagram, label: "Instagram", href: "https://www.instagram.com/emahubblyinn" },
  { icon: Facebook, label: "Facebook", href: "https://www.facebook.com/emahubblyinn" },
  { icon: Music2, label: "TikTok", href: "https://vm.tiktok.com/ZS9BLeaY6o2J4-FmaQJ/" },
  {
    icon: MessageCircle,
    label: "WhatsApp",
    href: waLink(VENUE.whatsappPrimary, `Hi ${VENUE.name}!`),
  },
];

export function Social() {
  return (
    <section className="relative py-20">
      <div className="mx-auto max-w-3xl px-5 text-center">
        <Reveal>
          <p className="section-label">Follow the nights</p>
          <div className="mt-7 flex justify-center gap-4">
            {SOCIALS.map((s) => (
              <a
                key={s.label}
                href={s.href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={s.label}
                className="group inline-flex h-13 w-13 items-center justify-center rounded-full border border-gold/40 p-4 text-gold transition-all hover:-translate-y-1 hover:bg-gold/10 hover:shadow-[0_0_30px_-8px_color-mix(in_oklab,var(--gold)_70%,transparent)]"
              >
                <s.icon className="h-5 w-5" />
              </a>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="relative overflow-hidden border-t border-border bg-charcoal/60 pb-24 pt-16 lg:pb-16">
      <div className="mx-auto max-w-6xl px-5">
        <div className="grid gap-10 sm:grid-cols-3">
          <div>
            <img
              src={logo.url}
              alt="EMA Hubbly Inn logo"
              loading="lazy"
              width={80}
              height={80}
              className="h-16 w-16 rounded-full ring-1 ring-gold/40"
            />
            <p className="mt-4 text-lg tracking-[0.2em] text-gold-light">EMA HUBBLY INN</p>
            <p className="text-[0.6rem] uppercase tracking-[0.34em] text-muted-foreground">
              Maboneng
            </p>
          </div>
          <div className="space-y-2 text-sm text-muted-foreground">
            <p className="section-label mb-3">Visit</p>
            <p>20 Kruger Street,</p>
            <p>Maboneng, Johannesburg</p>
            <p className="pt-3">
              {VENUE.hoursDays} | {VENUE.hoursTime}
            </p>
          </div>
          <div className="space-y-2 text-sm text-muted-foreground">
            <p className="section-label mb-3">Reach us</p>
            <a className="block hover:text-gold" href={`tel:${VENUE.phonePrimaryTel}`}>
              {VENUE.phonePrimary}
            </a>
            <a className="block hover:text-gold" href={`tel:${VENUE.phoneAltTel}`}>
              {VENUE.phoneAlt}
            </a>
            <a className="block break-words hover:text-gold" href={`mailto:${VENUE.email}`}>
              {VENUE.email}
            </a>
          </div>
        </div>

        <div className="gold-rule mt-12" />
        <p className="mt-8 text-center text-[0.6rem] uppercase tracking-[0.3em] text-gold sm:text-xs sm:tracking-[0.38em]">
          Good Vibes. Great People. Unforgettable Nights.
        </p>
        <p className="mt-5 text-center text-[0.6rem] uppercase tracking-[0.2em] text-muted-foreground">
          © {new Date().getFullYear()} EMA Hubbly Inn · Maboneng, Johannesburg
        </p>
      </div>
    </footer>
  );
}
