import { createFileRoute } from "@tanstack/react-router";
import { SiteNav } from "@/components/site/nav";
import { Hero } from "@/components/site/hero";
import {
  About,
  Contact,
  Experience,
  Footer,
  Gallery,
  GrandOpening,
  Hours,
  Location,
  Social,
} from "@/components/site/sections";
import { Booking } from "@/components/site/booking";

const TITLE = "EMA Hubbly Inn | Premium Hubbly Lounge in Maboneng, Johannesburg";
const DESCRIPTION =
  "EMA Hubbly Inn — Maboneng's premier nightlife destination. Premium hubblies, great music, ice cold drinks. Thursday to Sunday, 1 PM till late. Grand opening 5 September 2026.";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESCRIPTION },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESCRIPTION },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [{ rel: "canonical", href: "/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "BarOrPub",
          name: "EMA Hubbly Inn",
          description: DESCRIPTION,
          address: {
            "@type": "PostalAddress",
            streetAddress: "20 Kruger Street",
            addressLocality: "Maboneng, Johannesburg",
            addressCountry: "ZA",
          },
          telephone: "+27818885130",
          email: "support@hubblyinn.com",
          openingHours: "Th,Fr,Sa,Su 13:00-late",
        }),
      },
    ],
  }),
});

function Index() {
  return (
    <div className="relative">
      <SiteNav />
      <main>
        <Hero />
        <About />
        <Experience />
        <Gallery />
        <GrandOpening />
        <Hours />
        <Location />
        <Contact />
        <Booking />
        <Social />
      </main>
      <Footer />
    </div>
  );
}
